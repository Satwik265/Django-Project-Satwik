from django.contrib import admin
from .models import DrinksCategory, Drinks

admin.site.register(DrinksCategory)
admin.site.register(Drinks)

